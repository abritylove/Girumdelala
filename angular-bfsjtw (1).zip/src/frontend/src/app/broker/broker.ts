export class Broker {
    public userId!:number;
    public password!:string;
    public role!:string;
    public mobile!:string;
    public email!:string;
    public city!:string;
    public broName!:string;
}