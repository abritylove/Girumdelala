export class Customer{
    public userId!:number;
    public password!:string;
    public role!:string;
    public mobile!:string;
    public email!:string;
    public city!:string;
    public custName:string;
    
}