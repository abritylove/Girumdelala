import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-property',
  templateUrl: './admin-property.component.html',
  styleUrls: ['./admin-property.component.css']
})
export class AdminPropertyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
