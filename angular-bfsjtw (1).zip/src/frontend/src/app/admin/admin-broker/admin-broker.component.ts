import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-broker',
  templateUrl: './admin-broker.component.html',
  styleUrls: ['./admin-broker.component.css']
})
export class AdminBrokerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
